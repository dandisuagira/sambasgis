    <!-- End  Contact section -->
      <!-- Portfolio section -->
     
  <!--  Strat footer -->
    <footer>
        <div class="mb-0">
                <div class="col">
                    <h5>PSPIG UNTAN</h5>
                    <br>
                    {{-- <div class="nav">
                        <ul class="navbar-calopas">
                            <li><a href="#home">Home.</a></li>
                            <li><a href="#about">About Us.</a></li>
                            <li><a href="#portfolio">Portfolio.</a></li>
                            <li><a href="#blog">Blog.</a></li>
                            <li><a href="#contact-us">Contact Us.</a></li>
                        </ul>
                    </div> --}}
                    <h6>Copyright © 2022 Pemerintah Kabupaten Sambas <br>
                        Supported By PSPIG Universitas Tanjungpura</h6>
                </div>
        </div>
    </footer>