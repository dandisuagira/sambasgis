
<?php $__env->startSection('title','WebGIS Kabupaten Sambas'); ?>
<?php $__env->startSection('content'); ?>
    


    
    
    

    
    <!-- blog section -->
    <section class="blog bg-primary" id="blog">
        <div class="container bg-primary">
            <div class="rows">
                <h2 class="text-center p-1 mb-1 text-white">KATEGORI WILAYAH</h2>
                <div class="row">
                    <div class="articles" >
                       
                        <div class="article"  data-aos="fade-right">
                            <a href="<?php echo e(url('desa_index')); ?>"><h4>DESA</h4></a>
                            <img src="<?php echo e(asset('image/desasambas.png')); ?>" width="100%" alt="" data-aos="zoom-in-down">
                            <p>Berisi Informasi Pembangunan Wilayah Administrasi Kabupaten Sambas Berdasarkan Batas Desa</p>
                            <a href="<?php echo e(url('desa_index')); ?>"><button type="button" class="btn btn-info">Detail</button></a>
                        </div>
                        <div class="article"  data-aos="fade-right">
                            <a href="<?php echo e(route('kecamatan_index')); ?>"><h4>KECAMATAN</h4></a>
                            <img src="<?php echo e(asset('image/kecamatansambas.png')); ?>" width="100%" alt="" data-aos="zoom-in-down">
                            <p>Berisi Informasi Pembangunan Wilayah Administrasi Kabupaten Sambas Berdasarkan Batas Kecamatan</p>
                            <a href="<?php echo e(route('kecamatan_index')); ?>"><button type="button" class="btn btn-info">Detail</button></a>
                        </div>
                        <div class="article"  data-aos="fade-right">
                            <a href="www.google.com"><h4>KABUPATEN</h4></a>
                            <img src="<?php echo e(asset('image/pendidikan.png')); ?>" width="100%" alt="" data-aos="zoom-in-down">
                            <p>Berisi Informasi Pembangunan Wilayah Administrasi Kabupaten Sambas Berdasarkan Batas Kabupaten</p>
                            <a href="#"><button type="button" class="btn btn-info">Detail</button></a>
                        </div>
                    </div>
                </div>
            </div>
    
        </div>
    </section>
    



    
    <!-- End Portfolio section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template_frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sambasgis\resources\views/frontend/home.blade.php ENDPATH**/ ?>