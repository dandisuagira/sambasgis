<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WebGIS Kabupaten Sambas</title>
    <!-- icon of the title bar -->
    <link rel="icon" href="img/favicon.png" type="image/icon type">
    <!-- Main Template css file -->
    
    
    <link rel="stylesheet" href="<?php echo e(asset('doob/css/style.css')); ?>">
    <!--  normalize css file -->
    <link rel="stylesheet" href="<?php echo e(asset('doob/css/normalize.css')); ?>">
    <!-- Font Awesome Library -->
    <link rel="stylesheet" href="<?php echo e(asset('doob/css/all.min.css')); ?>">
    <!--  Google font :  Work Sans -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@200;300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <!-- AOS Animate On Scroll Library -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>
<body>
<!-- start header -->
    <header class="home" id="home">
        <div class="container">
            <!-- Start nav bar  -->
            <nav class="nav-bar">
                <a href="#" class="navbar-band" >
                    <img src="<?php echo e(asset('doob/img/webgis.png')); ?>" alt=""> 
                  
                </a>
                <nav>
                    <ul class="navbar-calopas">
                        <li><a href="#home">Beranda</a></li>
                        <li><a href="#about">Analisis</a></li>
                        <li><a href="#portfolio">Geoportal</a></li>
                        <li><a href="#contact-us">Tentang</a></li>
                        
                    </ul>
                </nav>
                <button hrf="www.google.com" class="btn-primary">Login</button>  
            </nav>
        </div>
        <!-- End Nav Bar  -->
        <div class="container-fluid">
            <img src="<?php echo e(asset('doob/img/hero.svg')); ?>" alt="home">
        </div>
        <section class="container">
            <article class="main-home" >
                <div class="text">
                    <h1>Portal Resmi<br> Kabupaten Sambas</h1>
                    <p>Dikelola Oleh : BAPPEDA Kabupaten Sambas <br>Jl. Pembangunan, Dalam Kaum, Kec. Sambas, Kabupaten Sambas, Kalimantan Barat 79462</p>
                </div>
                <div class="btns">
                    <a href="#about" class="btn-special">more about us</a>
                    <a  href="#">get in touch.</a>
                </div>
            </article>
        </section>
    </header>
    <!-- End header -->

    <!--  End SERVICES SECTION -->
    <!-- About section  -->
    
    <!--  End About section -->
    <!-- Portfolio section -->
    <section class="portfolio" id="portfolio">

        <div class="container">
            <div class="rows">
                <div class="row row1" data-aos="fade-down-right">
                    <h2 style="text-align: center">Kategori Peta</h2>
                </div>
                <div class="row row2" >
                     <a href="www.google.com"><img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down"></a>
                    <img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down">
                    <img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down">
                    <img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down">
                    <img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down">
                    <img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down">
                </div>
            </div>

        </div>
    </section>
    <!-- End Portfolio section -->

    <!-- blog section -->
    
    <!-- End blog section -->
    <!-- Contact section -->
    <section class="contact-us" id="contact-us">
        <div class="container">
            <div class="rows">
                <div class="row row1">
                    <h2 data-aos="zoom-in-left">Hubungi Kami</h2>
                </div>
                <form action="" >
                    <div class="row row2">
                        <input type="email" placeholder="Your email" id="email-input" data-aos="fade-down-right">
                        <input type="text" placeholder="subject" id="subject-input" data-aos="fade-down-left">
                    </div>
                    <div class="row row3" data-aos="fade-up" >
                        <textarea cols="100" rows="5" id="message-input" maxlength="150">Message here...</textarea>
                        <a href="" class="btn-special" id="send">send message</a>
                    </div>
                    
                </form>
                
            </div>
        </div>

    </section>
    <!-- End  Contact section -->
    <!--  Strat footer -->
    <footer>
        <div class="container">
            <div class="rows">
                <div class="row row1">
                    <h5>PPIG UNTAN</h5>
                    
                    <h6>Copyright © 2022 Pemerintah Kabupaten Bengkayang. Supported By PSPIG Universitas Tanjungpura</h6>
                </div>
            </div>
        </div>
    </footer>
    <span class="scrollToTop" data-aos="fade-left" >
        <img src="<?php echo e(asset('doob/img/fi-rr-arrow-small-up.svg')); ?>" alt="icon"/>
    </span>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="<?php echo e(asset('doob/javascript/main.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\sambasgis\resources\views/masterfrontend.blade.php ENDPATH**/ ?>