
<?php $__env->startSection('title','Edit Dusun'); ?>

<?php $__env->startPush('css'); ?>
    <!--          -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <style>
        
        #map {
            width: 100%;
            height: 100vh;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <section>
        
    </section>
    <!-- About section  -->
    <section class="about" id="about">
        <div class="container-fluid">
            <div class="row">
              
              <div class="col-lg-12">
            
                <h2 class="text-center"><b>DETAIL DUSUN</b></h2>
                  <form action="<?php echo e(url('dusun/' . $model->id)); ?>}"  method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="_method" value="PATCH">
                    
                  <div class="row">  
                  <div class="form-group col-md-4">
                      <label for="">Nama Desa</label>
                      <input type="text" readonly class="form-control" name="nama_desa" value="<?php echo e($model->desa->nama_desa); ?>" placeholder="Nama Desa" required value="<?php echo e($errors->any() ? old('nama_desa') : ''); ?>">
                  </div>
                  <div class="form-group col-md-4">
                      <label for="">Kode Desa</label>
                      <input type="text" readonly class="form-control" name="desa_id" value="<?php echo e($model->desa_id); ?>" placeholder="Kode Desa" required value="<?php echo e($errors->any() ? old('kode_desa') : ''); ?>">
                  </div>
                  <div class="form-group col-md-4">
                      <label for="">Jumlah Dusun</label>
                      <input type="text" class="form-control" name="jumlah_dusun" value="<?php echo e($model->jumlah_dusun); ?>" placeholder="Jumlah Dusun" required value="<?php echo e($errors->any() ? old('jumlah_dusun') : ''); ?>">
                  </div>
                  </div>
                  
                  <div class="row">  
                      <div class="form-group col-md-4">
                          <label for="">Nama Dusun</label>
                          <input type="text" class="form-control" name="nama_dusun" value="<?php echo e($model->nama_dusun); ?>" placeholder="Nama Dusun" required value="<?php echo e($errors->any() ? old('nama_dusun') : ''); ?>">
                      </div>
                      <div class="form-group col-md-4">
                          <label for="">Jumlah RT</label>
                          <input type="text" class="form-control" name="rt" value="<?php echo e($model->rt); ?>" placeholder="Prioritas Desa" required value="<?php echo e($errors->any() ? old('rt') : ''); ?>">
                      </div>
                      <div class="form-group col-md-4">
                          <label for="">Jumlah RW</label>
                          <input type="text" class="form-control" name="rw" value="<?php echo e($model->rw); ?>" placeholder="Luas Desa" required value="<?php echo e($errors->any() ? old('rw') : ''); ?>">
                      </div>             
                  </div>

                  <?php if(auth()->guard()->check()): ?>
                  <a href="<?php echo e(url('dusun/'.$model->id.'/edit')); ?>"><button type="button" class="btn btn-info float-left mr-2 mb-2"><i class="fas fa-pencil-alt"></i> Edit</button></a>
                <?php else: ?>
                  
                <?php endif; ?>
                <a href="<?php echo e(route('dusun_index')); ?>"><button type="button" class="btn btn-danger float-left mr-2"><i class="fas fa-times"></i> Kembali</button></a>
      
                  </form>            
                      <!-- /.card-body -->
                    </div>
              </div>
            </div>
            <!-- /.row -->
          </div><!-- /.container-fluid -->
    </section>
    <!--  End About section -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>

<?php $__env->stopPush(); ?>



<?php echo $__env->make('template_frontend.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sambasgis\resources\views/frontend/dusun/show.blade.php ENDPATH**/ ?>