<!-- start header -->
<header class="home" id="home">
    <div class="container">
        <!-- Start nav bar  -->
        <nav class="nav-bar">
            <a href="#" class="navbar-band" >
                <img src="<?php echo e(asset('doob/img/webgis.png')); ?>" alt=""> 
              
            </a>
            <nav>
                <ul class="navbar-calopas">
                    <li><a href="#home">Beranda</a></li>
                    <li><a href="#about">Analisis</a></li>
                    <li><a href="#portfolio">Geoportal</a></li>
                    <li><a href="#contact-us">Tentang</a></li>
                    
                </ul>
            </nav>
            <button hrf="www.google.com" class="btn-primary">Login</button>  
        </nav>
    </div>
    <!-- End Nav Bar  -->
    
</header><?php /**PATH C:\xampp\htdocs\sambasgis\resources\views/frontend/header.blade.php ENDPATH**/ ?>