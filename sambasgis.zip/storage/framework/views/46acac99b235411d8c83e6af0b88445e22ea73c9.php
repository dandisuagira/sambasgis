    <!-- End  Contact section -->
      <!-- Portfolio section -->
     
  <!--  Strat footer -->
    <footer>
        <div class="mb-0">
                <div class="col">
                    <h5>PSPIG UNTAN</h5>
                    <br>
                    
                    <h6>Copyright © 2022 Pemerintah Kabupaten Sambas <br>
                        Supported By PSPIG Universitas Tanjungpura</h6>
                </div>
        </div>
    </footer><?php /**PATH C:\xampp\htdocs\sambasgis\resources\views/template_frontend/footer.blade.php ENDPATH**/ ?>