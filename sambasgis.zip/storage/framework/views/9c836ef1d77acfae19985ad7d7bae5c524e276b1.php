
<?php $__env->startSection('title','INDEX DUSUN'); ?>

<?php $__env->startPush('css'); ?>
    <!--          -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <style>
        
        #map {
            width: 100%;
            height: 100vh;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <section>
        
    </section>
    <!-- About section  -->
    <section class="about" id="about">
        <div class="container">
            <div class="row">
                <div class="col col1" data-aos="fade-right">
                    <div class="container-fluid">
                        <h2 class="text-center"><b>DUSUN</b></h2>
                        <a type="button" href="<?php echo e(route('dusun_index')); ?>" class="btn btn-primary float-right mt-2 mb-2">Peta Sebaran Dusun</a>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                <th scope="col">No</th>
                                <th>Kode Desa</th>
                                <th>Nama Desa</th>
                                <th>Jumlah Dusun</th>
                                <th>Nama Dusun</th>
                                <th>Total RT</th>
                                <th>Total RW</th>
                                <th colspan="2" style="width: 40px" style="text-align: center" align="center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($value->desa->kode_desa); ?></td>
                                <td><?php echo e($value->desa->nama_desa); ?></td>
                                <td><?php echo e($value->jumlah_dusun); ?></td>
                                <td><?php echo e($value->nama_dusun); ?></td>
                                <td><?php echo e($value->rt); ?></td>
                                <td><?php echo e($value->rw); ?></td>
                                    
                                    <td> 
                                      <a style="margin-right:7px" href="<?php echo e(route('dusun.edit', $value->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-eye"></i> Edit</a>
                                    </td>   
                                <td>        
                                    
                                    <form action="<?php echo e(url('dusun/'. $value->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button class="btn btn-danger btn-sm" onclick="return confirm('Hapus Data?')"><i class="fa fa-trash"></i> Delete</button>
                                </form>
                                </td>      
                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  End About section -->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('template_frontend.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sambasgis\resources\views/frontend/dusun/index.blade.php ENDPATH**/ ?>