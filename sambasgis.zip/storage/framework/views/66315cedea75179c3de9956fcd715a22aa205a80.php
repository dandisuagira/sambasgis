   <!-- Contact section -->
    <section class="contact-us" id="contact-us">
        <div class="container">
            <div class="rows">
                <div class="row row1">
                    <h2 data-aos="zoom-in-left">Hubungi Kami</h2>
                </div>
                <form action="" >
                    <div class="row row2">
                        <input type="email" placeholder="Your email" id="email-input" data-aos="fade-down-right">
                        <input type="text" placeholder="subject" id="subject-input" data-aos="fade-down-left">
                    </div>
                    <div class="row row3" data-aos="fade-up" >
                        <textarea cols="100" rows="5" id="message-input" maxlength="150">Message here...</textarea>
                        <a href="" class="btn-special" id="send">send message</a>
                    </div>
                    
                </form>
                
            </div>
        </div>

    </section>
    <!-- End  Contact section -->
  <!--  Strat footer -->
    <footer>
        <div class="container">
            <div class="rows">
                <div class="row row1">
                    <h5>PPIG UNTAN</h5>
                    
                    <h6>Copyright © 2022 Pemerintah Kabupaten Bengkayang. Supported By PSPIG Universitas Tanjungpura</h6>
                </div>
            </div>
        </div>
    </footer><?php /**PATH C:\xampp\htdocs\sambasgis\resources\views/frontend/footer.blade.php ENDPATH**/ ?>