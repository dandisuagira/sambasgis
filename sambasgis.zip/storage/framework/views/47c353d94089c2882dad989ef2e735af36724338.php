
<?php $__env->startSection('title','Tambah Proyek'); ?>

<?php $__env->startPush('css'); ?>
    <!--          -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <style>
        
        #map {
            width: 100%;
            height: 100vh;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <section>
        
    </section>
    <!-- About section  -->
    <section class="about" id="about">
        <div class="container">
            <div class="row">
                <div class="col" data-aos="fade-right">
                    <h2 class="text-center"><b>TAMBAH PROYEK</b></h2>
                    <form action="<?php echo e(route('proyek.store')); ?>"  method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">  
                            <div class="form-group col-md-6">
                                <label for="">Nama Proyek</label>
                                <input type="text" class="form-control" name="nama_proyek" placeholder="Nama Proyek" required value="<?php echo e($errors->any() ? old('id') : ''); ?>">
                            </div>
                            
                            
                            
                            <div class="form-group col-sm-6">
                                <label for="desa_id">Nama Desa </label>
                                <select name="desa_id" id="desa_id" class="form-control">
                                    <option disabled selected hidden>-Pilih Desa-</option>
                                    <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->kode_desa); ?>" <?php echo e(old('desa_id') == $item->kode_desa ? 'selected' : null); ?>>
                                        <?php echo e($item->nama_desa); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>


                        </div>

                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="">Lattitude</label>
                                <input type="text" class="form-control" name="lat" placeholder="Lattitude" required value="<?php echo e($errors->any() ? old('lat') : ''); ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Langitude</label>
                                <input type="text" class="form-control" name="long" placeholder="Longitude" required value="<?php echo e($errors->any() ? old('long') : ''); ?>">
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="">Foto</label>
                                <input type="file" class="form-control" name="foto1" placeholder="Foto" required value="<?php echo e($errors->any() ? old('foto') : ''); ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Tahun</label>
                                <input type="text" class="form-control" name="tahun" placeholder="Tahun" required value="<?php echo e($errors->any() ? old('tahun') : ''); ?>">
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="">Kode Proyek</label>
                                <input type="text" class="form-control" name="kode_proyek" placeholder="Kode Proyek" required value="<?php echo e($errors->any() ? old('kode_proyek') : ''); ?>">
                            </div>
                        </div>

                        <span><button style="margin-right:4px" type="submit" class="btn btn-success float-left"><i class="fas fa-save"></i> Simpan Data</button></span>
                        <a href="<?php echo e(url('desa')); ?>"><button type="button" class="btn btn-danger float-left mr-2"><i class="fas fa-times"></i> Kembali</button></a>


                    </form>
                </div>
            </div>
        </div>
    </section>
    <!--  End About section -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template_frontend.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sambasgis\resources\views/frontend/proyek/create.blade.php ENDPATH**/ ?>