
<?php $__env->startSection('title','Peta Analisis'); ?>

<?php $__env->startPush('css'); ?>
    <!--          -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <style>
        
        #map {
            width: 100%;
            height: 100vh;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <section>
        
    </section>
    <!-- About section  -->
    <section class="about" id="about">
        <div class="container">
            <div class="row">
                <div class="col col1" data-aos="fade-right">
                    <div class="container-fluid">
                        <h2 class="text-center"><b>TEST DESA</b></h2>
                        
                        <div id="map" class="container"></div>  
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  End About section -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>
    <!--   -->
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://code.jquery.com/ui/1.8.24/jquery-ui.min.js"></script>

    <script>
        // Inisialisasi MAP dasar  
        // osm map
        var map = L.map('map',{
          attributionControl: false, 
          center: [1.4460029868582618, 109.31332264681605],
          zoom: 10,
          minZoom: 7,
          maxZoom: 25,
          zoomControl: true
        });
        var osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            maxZoom: 25,
            maxNativeZoom: 19
        });
        osm.addTo(map);
        
         //google street
        var googleStreets = L.tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
                maxZoom: 20,
                subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
            });
            // googleStreets.addTo(map);

            //google satelite 
        var googleSat = L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
                maxZoom: 20,
                subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
            });
            // googleSat.addTo(map);


        var marker = L.marker([1.4149386434390463, 109.32303328065888]).bindPopup("<b>Kabupaten Sambas!</b>")
        .addTo(map);
        
        var admStyle = {
            fillColor : "black",
            color : "blue",
            weight : 1,
            oppacity : 1,
            fillOppacity : 0.5,
        };
        var admStyle1 = {
            icon : yellowIcon,
        };

        
        var wfs_url_adm = 'http://sambaskab.ina-sdi.or.id:8080/geoserver/BAPPEDA/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=BAPPEDA:admin_desa_sambas_biropemkalbar_des2019_610120220828171840&maxFeatures=50&outputFormat=application%2Fjson&srsName=epsg:4326';
        var wfs_url_pendidikan = 'http://sambaskab.ina-sdi.or.id:8080/geoserver/ADMIN/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=ADMIN:jo_pendidikan_sederajat_sambas_pt_50k_610120220828190649&maxFeatures=50&outputFormat=application%2Fjson&srsName=epsg:4326';
        var wfs_url_bky = 'http://localhost:8080/geoserver/bengkayang/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=bengkayang%3Aadministrasi_kabupaten_ln_610720220822095811&maxFeatures=50&outputFormat=application%2Fjson&srsName=epsg:4326'

        //buat variabel penampung agar dapat overlay
        var sambasAdm = new L.layerGroup();
        var smp = new L.layerGroup();

        //icon 
        var yellowIcon = new L.Icon({
        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-yellow.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41]
        });


        //sambas adm
        $.getJSON(wfs_url_adm).then((res) =>{
            var layer = L.geoJson(res, {
                onEachFeature: function(f,l) {
                    // console.log(res);
                    l.bindPopup("Geometry : " +f.geometry.coordinates + "Nama Desa: " + f.properties.namobj + '<br>' + "Nama Kecamatan: " + f.properties.wiadkc)
                },
                style : admStyle,
            }).addTo(sambasAdm);
            map.fitBounds(layer.getBounds());
        })
        

        //data pendidikan dgn format lat long
        $.getJSON(wfs_url_pendidikan, function(data) {
        sd = L.geoJSON(data, {
            pointToLayer: function(feature, latlng) {
                return L.marker(latlng, {
                    icon: yellowIcon
                });
            },
            onEachFeature(feature, layer) {
                    popupOptions = {
                        maxWidth: 200
                    };
                    //layer.bindPopup("Nama Sekolah: " + feature.properties.namobj + "<br> Jenjang: " + feature.properties.remark);
                }
            }).addTo(smp);
            console.log(data)
        });

        //sambas pendidikan
        // $.getJSON(wfs_url_pendidikan, function(data) {
        // penduduk = L.geoJson(data, {
        //     style: function(feature) {
        //             return {
        //                 icon: yellowIcon,
        //             }
        //         },
        //         onEachFeature(feature, layer) {
        //                 popupOptions = {
        //                     maxWidth: 200
        //                 };
        //             layer.bindPopup("Nama Sekolah: " + feature.properties.namobj + "<br> Jenjang: " + feature.properties.remark);

        //         }
        //     }).addTo(map);
        // });

        //bky adm
        $.getJSON(wfs_url_bky).then((res) =>{
            var layer = L.geoJson(res).addTo(map);
            map.fitBounds(layer.getBounds());
        })

        
        //datas desa dari mysql
        var array = [];
            <?php foreach ($datas as $key=>$value) { ?>
            var myStyle = {
                "color" : 'red',
                "fillColor" : 'green',
                "weight": 1,
                "opacity": 5
            };
            var drawnItems = L.geoJson(<?php echo $value->geojson_desa; ?>, {
                style: myStyle
            }).bindPopup(
                '<table class="table table-hover table-responsive table-info table-sm"><h4 class="text-center">Detail Desa</h4><hr><tr><td class="bg-primary">Nama Desa</td><td><?= $value->nama_desa ?></td></tr><tr><td class="bg-primary">Kode Desa</td><td><?= $value->kode_desa ?></td></tr><tr><td class="bg-primary">Kecamatan</td><td><?= $value->kecamatan ?></td></tr><tr><td class="bg-primary">Status Desa Prioritas</td><td><?= $value->prioritas_desa ?></td></tr><tr><a href="google.com" class="btn btn-primary">Detail Desa</a></tr></table>'
                )
            array.push(drawnItems);
            <?php }; ?>
            var datas = L.featureGroup(array).addTo(map);


            // layer controller
            var baseMaps = {
                "OSM": osm,
                "Google Street": googleStreets,
                "Google Sattelite": googleSat,
            };

            var overlayMaps = {
                "Marker": marker,
                "SMP": smp,
                "Sambas": sambasAdm,
                
            };
            L.control.layers(baseMaps, overlayMaps, {
                collapsed: true,
                position: 'topright'
            }).addTo(map);

            
        </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('template_frontend.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sambasgis\resources\views/frontend/desa.blade.php ENDPATH**/ ?>