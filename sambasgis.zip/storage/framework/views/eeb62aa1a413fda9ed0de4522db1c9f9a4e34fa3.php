<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WebGIS Kabupaten Sambas</title>
    <!-- icon of the title bar -->
    <link rel="icon" href="img/favicon.png" type="image/icon type">
    <!-- Main Template css file -->
    
    
    <link rel="stylesheet" href="<?php echo e(asset('doob/css/style.css')); ?>">
    <!--  normalize css file -->
    <link rel="stylesheet" href="<?php echo e(asset('doob/css/normalize.css')); ?>">
    <!-- Font Awesome Library -->
    <link rel="stylesheet" href="<?php echo e(asset('doob/css/all.min.css')); ?>">
    <!--  Google font :  Work Sans -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@200;300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <!-- AOS Animate On Scroll Library -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>
<body>
<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End header -->
    <div class="container-fluid">
        <img src="<?php echo e(asset('doob/img/hero.svg')); ?>" alt="home">
    </div>
    <section class="container">
        <article class="main-home" >
            <div class="text">
                <h1>Portal Resmi<br> Kabupaten Sambas</h1>
                <p>Dikelola Oleh : BAPPEDA Kabupaten Sambas <br>Jl. Pembangunan, Dalam Kaum, Kec. Sambas, Kabupaten Sambas, Kalimantan Barat 79462</p>
            </div>
            <div class="btns">
                <a href="#about" class="btn-special">more about us</a>
                <a  href="#">get in touch.</a>
            </div>
        </article>
    </section>

    <!--  End SERVICES SECTION -->
    <!-- About section  -->
    <section class="about" id="about">
        <div class="container">
            <div class="columms">
                <div class="col col1" data-aos="fade-right">
                    <div class="image">
                        <img src="<?php echo e(asset('doob/img/aboutimg.svg')); ?>" alt="">
                    </div>
                </div>
                <div class="col col2" data-aos="fade-left">
                    <div class="text">
                        <h4>OUR COMPANY</h4>
                        <h2>Some Fine <br>
                        Words About Us</h2>
                        <p>estibulum ac diam sit amet quam vehicula elementum amet est on dui. Nulla porttitor accumsan tincidunt.Vestibulum ac
                        diam sit amet.
                        Quam vehicula elementum amet est on dui. Nulla porttitor accumsan tincidunt.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  End About section -->
    <!-- Portfolio section -->
    <section class="portfolio" id="portfolio">

        <div class="container">
            <div class="rows">
                <div class="row row1" data-aos="fade-down-right">
                    <h2 style="text-align: center">Kategori Peta</h2>
                </div>
                <div class="row row2" >
                     <a href="www.google.com"><img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down"></a>
                    <img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down">
                    <img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down">
                    <img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down">
                    <img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down">
                    <img src="<?php echo e(asset('doob/img/1.png')); ?>" alt="" data-aos="zoom-in-down">
                </div>
            </div>

        </div>
    </section>
    <!-- End Portfolio section -->

    <!-- blog section -->
    
    <!-- End blog section -->
   
<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <span class="scrollToTop" data-aos="fade-left" >
        <img src="<?php echo e(asset('doob/img/fi-rr-arrow-small-up.svg')); ?>" alt="icon"/>
    </span>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="<?php echo e(asset('doob/javascript/main.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\sambasgis\resources\views/frontend/master.blade.php ENDPATH**/ ?>